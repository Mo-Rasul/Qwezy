import {
  ChatBubbleLeftIcon,
  CircleStackIcon,
  HomeIcon,
} from "@heroicons/react/24/outline";

export const navigation = [
  {
    name: "Home",
    href: "/app/",
    icon: HomeIcon,
    current: false,
  },
  {
    name: "Databases",
    href: "/app/databases/",
    icon: CircleStackIcon,
    current: false,
  },
  {
    name: "Chat",
    href: "/app/chat/",
    icon: ChatBubbleLeftIcon,
    current: false,
  },
];
