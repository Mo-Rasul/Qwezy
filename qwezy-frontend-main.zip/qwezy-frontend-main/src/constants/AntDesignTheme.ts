export const ANT_DESIGN_THEME = {
  token: {
    fontFamily: "Roboto",
  },
  components: {
    Button: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
      primaryShadow: "none",
    },
    Input: {
      colorPrimary: "#36917E",
      // algorithm: true, // Enable algorithm
    },
    Switch: {
      colorPrimary: "#36917E",
      colorBgContainer: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Checkbox: {
      colorPrimary: "#36917E",
      colorBgContainer: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Select: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Upload: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Steps: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Radio: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Tabs: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    DatePicker: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
    Spin: {
      colorPrimary: "#36917E",
      algorithm: true, // Enable algorithm
    },
  },
};
