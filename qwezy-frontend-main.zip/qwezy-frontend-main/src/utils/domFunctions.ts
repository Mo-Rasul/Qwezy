export function HandlePrimaryColorChange(color: string) {
  document.documentElement.style.setProperty("--color-primary", color);
}
export function HandleSecondaryColorChange(color: string) {
  document.documentElement.style.setProperty("--color-secondary", color);
}
export function HandleBackgroundColorChange(color: string) {
  document.documentElement.style.setProperty("--color-background", color);
}
export function HandleGrandientColorChange(color: string, color2: string) {
  document.documentElement.style.setProperty("--color-grandient-start", color);
  document.documentElement.style.setProperty("--color-grandient-end", color2);
}
