export function Truncate(fileName: string) {
  const fileNameLength = fileName.length;

  if (fileNameLength < 15) {
    return fileName;
  } else {
    const middleRemovedName = `${fileName.substring(0, 20)}...`;
    return middleRemovedName;
  }
}
