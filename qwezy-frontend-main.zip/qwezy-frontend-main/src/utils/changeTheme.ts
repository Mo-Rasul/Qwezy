import {
  HandleBackgroundColorChange,
  HandleGrandientColorChange,
  HandlePrimaryColorChange,
  HandleSecondaryColorChange,
} from "./domFunctions";

export const ChangeTheme = (theme: any) => {
  console.log(theme);
  HandlePrimaryColorChange(
    `${theme.primary.r} ${theme.primary.g} ${theme.primary.b}`
  );
  HandleSecondaryColorChange(
    `${theme.secondary.r} ${theme.secondary.g} ${theme.secondary.b}`
  );
  HandleBackgroundColorChange(
    `${theme.background.r} ${theme.background.g} ${theme.background.b}`
  );
  HandleGrandientColorChange(
    `${theme.gradient1.r} ${theme.gradient2.g} ${theme.gradient1.b}`,
    `${theme.gradient2.r} ${theme.gradient2.g} ${theme.gradient2.b}`
  );
};
