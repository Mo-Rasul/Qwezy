"use client";

import { Logo } from "@/components/Logo";
import { useAuth } from "@/hooks/useAuth";
import { Button, Form, Input } from "antd";
import Link from "next/link";
import React, { useState } from "react";

export default function Page() {
  //** states */
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<any>({ password: null });

  const auth = useAuth();
  const onFinish = (values: any) => {
    setLoading(true);
    setErrors({ password: null });

    const { email, password } = values;
    auth.login(
      { email, password },
      (data: any) => {
        setErrors({ password: data });
      },
      () => setLoading(false),
    );
  };

  return (
    <>
      <div className="flex min-h-svh flex-1">
        <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
          <div className="mx-auto w-full max-w-sm lg:w-96">
            <div>
              <Logo />
              <h2 className="mt-8 text-2xl font-bold leading-9 tracking-tight text-gray-900">
                Sign in to your account
              </h2>
              <p className="mt-2 text-sm leading-6 text-gray-500">
                Not a member?{" "}
                <Link
                  href="/auth/register"
                  className="font-semibold text-primary hover:text-secondary"
                >
                  Register
                </Link>
              </p>
            </div>

            <div className="mt-10">
              <div>
                <Form
                  name="basic"
                  layout="vertical"
                  onFinish={onFinish}
                  className="space-y-6"
                >
                  <Form.Item
                    label="Email address"
                    name="email"
                    rules={[
                      { required: true, message: "Please input your email!" },
                      { type: "email", message: "Invalid email" },
                    ]}
                  >
                    <Input type="email" autoComplete="email" />
                  </Form.Item>

                  <Form.Item
                    label="Password"
                    name="password"
                    rules={[
                      {
                        required: true,
                        message: "Please input your password!",
                      },
                    ]}
                  >
                    <Input.Password autoComplete="current-password" />
                  </Form.Item>

                  <Form.Item>
                    <div className="flex items-center justify-between">
                      <div />
                      <a
                        href="#"
                        className="font-semibold text-primary hover:text-secondary"
                      >
                        Forgot password?
                      </a>
                    </div>
                  </Form.Item>

                  {errors.password && (
                    <p className="text-xs capitalize text-red-500">
                      {errors.password}
                    </p>
                  )}

                  <Form.Item>
                    <Button
                      type="primary"
                      htmlType="submit"
                      className="w-full"
                      loading={loading}
                    >
                      Sign In
                    </Button>
                  </Form.Item>
                </Form>
              </div>
            </div>
          </div>
        </div>
        <div className="relative hidden w-0 flex-1 lg:block">
          <div className="absolute inset-0 h-full w-full bg-gradient-to-b from-primary to-secondary object-cover" />
        </div>
      </div>
    </>
  );
}
