"use client";

import { Logo } from "@/components/Logo";
import { useAuth } from "@/hooks/useAuth";

import { Button, Form, Input } from "antd";
import Link from "next/link";
import React, { useState } from "react";

export default function Page() {
  //** states */
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<any>({ password: null });

  const auth = useAuth();

  const onFinish = (values: any) => {
    setLoading(true);
    setErrors({ password: null });
    const { email, password, name, phone } = values;
    auth.register(
      { email, password, name, phone },
      (data: any) => {
        setErrors({ password: data });
      },
      () => setLoading(false),
    );
  };
  return (
    <>
      <div className="flex min-h-svh flex-1">
        <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
          <div className="mx-auto w-full max-w-sm lg:w-96">
            <div>
              <Logo />
              <h2 className="mt-8 text-2xl font-bold leading-9 tracking-tight text-gray-900">
                Create your account
              </h2>
              <p className="mt-2 text-sm leading-6 text-gray-500">
                Already have an account?{" "}
                <Link
                  href="/auth/login"
                  className="font-semibold text-primary hover:text-secondary"
                >
                  Sign in
                </Link>
              </p>
            </div>

            <div className="mt-10">
              <div>
                <Form
                  name="register"
                  layout="vertical"
                  onFinish={onFinish}
                  className="space-y-6"
                >
                  <Form.Item
                    label="Name"
                    name="name"
                    rules={[
                      { required: true, message: "Please input your name!" },
                    ]}
                  >
                    <Input type="text" autoComplete="name" />
                  </Form.Item>

                  <Form.Item
                    label="Phone"
                    name="phone"
                    rules={[
                      {
                        required: true,
                        message: "Please input your phone number!",
                      },
                      {
                        pattern: /^[0-9]+$/,
                        message: "Please enter a valid phone number",
                      },
                    ]}
                  >
                    <Input type="tel" autoComplete="tel" />
                  </Form.Item>

                  <Form.Item
                    label="Email address"
                    name="email"
                    rules={[
                      { required: true, message: "Please input your email!" },
                      { type: "email", message: "Invalid email" },
                    ]}
                  >
                    <Input type="email" autoComplete="email" />
                  </Form.Item>

                  <Form.Item
                    label="Password"
                    name="password"
                    rules={[
                      {
                        required: true,
                        message: "Please input your password!",
                      },
                    ]}
                  >
                    <Input.Password autoComplete="new-password" />
                  </Form.Item>

                  {errors.password && (
                    <p className="text-xs capitalize text-red-500">
                      {errors.password}
                    </p>
                  )}

                  <Form.Item>
                    <Button
                      type="primary"
                      htmlType="submit"
                      className="w-full"
                      loading={loading}
                    >
                      Register
                    </Button>
                  </Form.Item>
                </Form>
              </div>
            </div>
          </div>
        </div>
        <div className="relative hidden w-0 flex-1 lg:block">
          <div className="absolute inset-0 h-full w-full bg-gradient-to-b from-primary to-secondary object-cover" />
        </div>
      </div>
    </>
  );
}
