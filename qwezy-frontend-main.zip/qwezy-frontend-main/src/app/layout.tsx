import type { Metadata } from "next";
import "./globals.css";
import { Poppins } from "next/font/google";
import { ConfigProvider } from "antd";
import { AntdRegistry } from "@ant-design/nextjs-registry";
import RootWrapper from "@/hoc/RootWrapper";
import { ANT_DESIGN_THEME } from "@/constants/AntDesignTheme";

export const metadata: Metadata = {
  title: "Qwezy",
  description: "Seamless SQL Management with AI-Powered Assistance",
};

const poppins = Poppins({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-poppins",
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${poppins.variable}`}>
        <ConfigProvider theme={ANT_DESIGN_THEME}>
          <AntdRegistry>
            <RootWrapper>{children}</RootWrapper>
          </AntdRegistry>
        </ConfigProvider>
      </body>
    </html>
  );
}
