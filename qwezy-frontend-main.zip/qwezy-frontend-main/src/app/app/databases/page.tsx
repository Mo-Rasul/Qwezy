"use client";

import {
  AddDatabase,
  DeleteDatabase,
  GetDatabases,
  TestConnection,
  UpdateDatabase,
} from "@/Client/request";
import { DbsLoadingSkelton } from "@/components/Skeltons/DbsLoadingSkelton";
import {
  MagnifyingGlassIcon,
  PencilIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import {
  Empty,
  Modal,
  Tooltip,
  Form,
  Input,
  Button,
  Select,
  message,
  Dropdown,
} from "antd";
import moment from "moment";
import Image from "next/image";
import Link from "next/link";
import React, { useEffect, useState } from "react";

const { Option } = Select;

export default function Page() {
  //** states */
  const [data, setData] = useState<any>(null);
  const [filteredData, setFilteredData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [trigger, settrigger] = useState(false);
  const [currentItem, setCurrentItem] = useState(null);

  //** form instance */
  const [form] = Form.useForm();

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
    setCurrentItem(null);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    setCurrentItem(null);
  };

  function handleSearch(s: any) {
    if (s === "") setFilteredData(data);
    const f = searchArray(data, s);
    setFilteredData(f);
  }

  function searchArray(array: any, searchText: string) {
    // Convert the search text to lower case for case-insensitive search
    const lowercasedSearchText = searchText.toLowerCase();

    return array.filter((obj: any) => {
      // Check if any value in the object matches the search text
      return Object.values(obj).some((value: any) => {
        // Handle nested objects or JSON strings
        if (typeof value === "object" && value !== null) {
          return JSON.stringify(value)
            .toLowerCase()
            .includes(lowercasedSearchText);
        }
        // Convert value to a string and check if it includes the search text
        return String(value).toLowerCase().includes(lowercasedSearchText);
      });
    });
  }

  function handleTrigger() {
    GetDatabases().then((res: any) => {
      if (res.data) {
        setData(res.data);
        setFilteredData(res.data);
      } else {
        setData([]);
      }
      setLoading(false);
      settrigger(false);
    });
  }

  useEffect(() => {
    handleTrigger();
  }, []);

  useEffect(() => {
    if (trigger) handleTrigger();
  }, [trigger]);

  const handleMenuClick = (item: any, type: "edit" | "del") => {
    setCurrentItem(item);

    if (type === "edit") showModal();
    else {
      DeleteDatabase(item.id).then((res: any) => {
        if (res.data) {
          settrigger(true);
          message.success("Database deleted successfully");
        } else {
          message.error("Failed to delete database");
        }
      });
    }
  };

  const menuProps = (item: any) => ({
    items: [
      {
        label: "Edit",
        key: "1",
        icon: <PencilIcon className="size-4" />,
        onClick: () => handleMenuClick(item, "edit"),
      },
      {
        label: "Delete",
        key: "2",
        danger: true,
        icon: <TrashIcon className="size-4" />,
        onClick: () => handleMenuClick(item, "del"),
      },
    ],
  });
  return (
    <>
      <Modal
        title={currentItem ? "Update Database" : "Add a New Database"}
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={<></>}
      >
        <DatabaseForm
          ok={handleOk}
          cancel={handleCancel}
          settrigger={settrigger}
          update={currentItem}
          form={form}
        />
      </Modal>

      <div className="databases">
        <div className="flex flex-col items-start justify-start gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-semibold lg:text-4xl">Databases</h1>
            <p className="text-sm opacity-55">
              View, update, delete or add databases
            </p>
          </div>
          <div className="flex items-center justify-center gap-4">
            <Input
              prefix={<MagnifyingGlassIcon className="h-4 w-4" />}
              placeholder="Search..."
              className="sm:!w-56"
              onChange={(e: any) => handleSearch(e.target.value)}
            />
            <Tooltip title={"Add a new database"}>
              <Button type="primary" onClick={() => showModal()}>
                Add New
              </Button>
            </Tooltip>
          </div>
        </div>
        <div className="mt-7 flex flex-wrap items-center justify-start gap-5">
          {!loading &&
            filteredData &&
            filteredData.map((item: any, index: number) => {
              return (
                <div key={index}>
                  <Tooltip title={"Connect to " + item.name}>
                    <Dropdown menu={menuProps(item)} trigger={["contextMenu"]}>
                      <Link
                        href={"/app/db?id=" + item.id}
                        className="relative flex cursor-pointer items-center justify-start gap-4 rounded-lg border bg-white px-5 py-8 transition-all duration-300 hover:border-primary"
                      >
                        <Image
                          src={
                            item.type === "MySQL"
                              ? "/logos/mysql.svg"
                              : item.type === "MSSQL"
                                ? "/logos/ms-sql.svg"
                                : "/logos/postgresql.svg"
                          }
                          alt={item.type}
                          height={100}
                          width={80}
                        />
                        <div>
                          <h2 className="text-xl">{item.name}</h2>
                          <p className="text-xs opacity-40">
                            {moment(item.createdAt).format(
                              "YYYY-MM-DD hh:mm a",
                            )}
                          </p>
                        </div>
                      </Link>
                    </Dropdown>
                  </Tooltip>
                </div>
              );
            })}
          {!loading && filteredData && filteredData.length === 0 && (
            <div className="flex w-full items-center justify-center">
              <Empty description="No databases found" />
            </div>
          )}
        </div>
        {loading && (
          <div className="laoding-skelton">
            <DbsLoadingSkelton />
          </div>
        )}
      </div>
    </>
  );
}

const DatabaseForm = ({
  ok,
  cancel,
  settrigger,
  update,
  form,
}: {
  ok: any;
  cancel: any;
  settrigger: any;
  update: any;
  form: any;
}) => {
  //** states */
  const [loading, setLoading] = useState(false);
  const [loadingConnection, setLoadingConnection] = useState(false);
  const [err, setErr] = useState("");
  const [isTestConnection, setIsTestConnection] = useState(false);

  const onFinish = (values: any) => {
    console.log("Form Values: ", values);

    if (isTestConnection) {
      setLoadingConnection(true);
      TestConnection(values).then((res: any) => {
        if (res.data) {
          message.success("Connection is Valid");
        } else {
          setErr(res.error.response.data.message);
        }
        setLoadingConnection(false);
      });
    } else {
      setLoading(true);
      if (update) {
        UpdateDatabase(values, update.id).then((res: any) => {
          if (res.data) {
            ok();
            settrigger(true);
            message.success("Database successfully updated");
            form.resetFields();
          } else {
            setErr("Failed to update database");
          }
          setLoading(false);
        });
      } else {
        AddDatabase(values).then((res: any) => {
          if (res.data) {
            ok();
            settrigger(true);
            message.success("Database successfully added");
            form.resetFields();
          } else {
            setErr("Failed to add database");
          }
          setLoading(false);
        });
      }
    }
  };

  const populateFields = () => {
    if (update) {
      form.setFieldValue("databaseType", update.type);
      form.setFieldValue("name", update.name);
    }
  };

  useEffect(() => {
    populateFields();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    populateFields();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [update]);

  return (
    <Form
      form={form}
      layout="vertical"
      onFinish={onFinish}
      initialValues={{
        databaseType: "MySQL", // Default value for database type
      }}
    >
      <Form.Item
        label="Host"
        name="host"
        rules={[{ required: true, message: "Please enter the host" }]}
      >
        <Input placeholder="Host" />
      </Form.Item>

      <Form.Item
        label="Port"
        name="port"
        rules={[{ required: true, message: "Please enter the port number" }]}
      >
        <Input type="number" placeholder="Port (e.g. 3306)" />
      </Form.Item>

      <Form.Item
        label="Username"
        name="username"
        rules={[{ required: true, message: "Please enter the username" }]}
      >
        <Input placeholder="Username (e.g. logicleaps)" />
      </Form.Item>

      <Form.Item
        label="Password"
        name="password"
        rules={[{ required: true, message: "Please enter the password" }]}
      >
        <Input.Password placeholder="Password" />
      </Form.Item>

      <Form.Item
        label="Database Type"
        name="databaseType"
        rules={[{ required: true, message: "Please select a database type" }]}
      >
        <Select>
          <Option value="MySQL">MySQL</Option>
          <Option value="PostgreSQL">PostgreSQL</Option>
          <Option value="MSSQL">MS SQL</Option>
        </Select>
      </Form.Item>

      <Form.Item
        label="Database Name"
        name="databaseName"
        rules={[{ required: true, message: "Please enter the database name" }]}
      >
        <Input placeholder="Database Name" />
      </Form.Item>

      <Form.Item
        label="Name"
        name="name"
        rules={[
          {
            required: true,
            message: "Please enter a name for this connection",
          },
        ]}
      >
        <Input placeholder="Connection Name (e.g. Qwezy DB)" />
      </Form.Item>

      {err !== "" && <p className="pb-2 text-red-500">{err}</p>}

      <div className="flex !w-full items-end justify-end gap-2">
        <Button onClick={() => cancel()} disabled={loading}>
          Cancel
        </Button>
        <Button
          type="primary"
          htmlType="submit"
          loading={loadingConnection}
          disabled={loadingConnection}
          onClick={() => {
            setIsTestConnection(true);
            form.submit();
          }}
        >
          Test Connection
        </Button>
        <Button
          type="primary"
          htmlType="submit"
          disabled={loading}
          loading={loading}
          onClick={() => {
            setIsTestConnection(false);
            form.submit();
          }}
        >
          Submit
        </Button>
      </div>
    </Form>
  );
};
