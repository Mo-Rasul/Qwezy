"use client";

import React, { useEffect, useState } from "react";
import ReactEcharts from "echarts-for-react";
import { Skeleton } from "antd";
import { renderWelcomeMsg } from "@/utils/WelcomeMsgUtil";
import { useAuth } from "@/hooks/useAuth";
import { GetStatistics } from "@/Client/request";

export default function Kpi() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  //** auth */
  const auth = useAuth();

  useEffect(() => {
    GetStatistics().then((res: any) => {
      if (res.data) {
        setData(res.data);
      }
      setLoading(false);
    });
  }, []);
  return (
    <div className="dashboard-home">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-semibold lg:text-4xl">Dashboard</h1>
        <h4 className="text-lg text-gray-600">
          {renderWelcomeMsg()}, {auth.user?.name} 👋
        </h4>
      </div>
      {loading ? (
        <div className="mt-5 flex flex-col gap-3">
          <Skeleton active />
          <Skeleton active />
          <Skeleton active />
        </div>
      ) : (
        data && <KPIModule data={data} />
      )}
    </div>
  );
}

function KPIModule({ data }: { data: any }) {
  function createRandomColorPicker(colors: string[]) {
    let availableColors = [...colors];

    return function pickRandomColor() {
      if (availableColors.length === 0) {
        // Reset the colors if all have been picked
        availableColors = [...colors];
      }

      // Get a random index from the availableColors array
      const randomIndex = Math.floor(Math.random() * availableColors.length);

      // Remove the color at the random index and return it
      return availableColors.splice(randomIndex, 1)[0];
    };
  }

  // Example usage:
  const colors = ["#5B93FF", "#FFD66B", "#FF8F6B", "#838893", "#A133FF"];
  const pickColor = createRandomColorPicker(colors);

  const DATABASE_TYPES = data.databases_types.map((item: any) => ({
    name: item.name,
    value: item.value,
    itemStyle: { color: pickColor() },
  }));
  const SUCCESS_FAIL_RATIO = data.success_fail_rate.map((item: any) => ({
    name: item.name.charAt(0).toUpperCase() + item.name.slice(1),
    value: item.value,
    itemStyle: { color: item.name === "fail" ? "#FF6363" : "#39C85C" },
  }));
  const salesBarChartData = {
    title: {
      text: "Resoruces Matrices Per Month",
      textStyle: {
        fontSize: 18,
        fontWeight: 500,
        color: "#000000",
      },
      left: "left",
      top: "top",
    },
    grid: {
      left: "2%",
      right: "2%",
      bottom: "5%",
      top: "15%",
      containLabel: true,
    },
    xAxis: {
      axisLabel: {
        show: true,
        color: "#A0AEC0", // Set the data item color
        fontSize: 14, // Set the font size
        fontWeight: 500, // Set the font weight
        margin: 20,
      },
      type: "category",
      data: data.resources_hit_per_month.months,

      axisLine: {
        show: false, // Hide the xAxis line
      },
      axisTick: {
        show: false,
      },
      splitLine: {
        show: true,
        lineStyle: {
          type: "dashed",
        },
      },
    },
    yAxis: {
      axisLabel: {
        show: true,
        color: "#A0AEC0", // Set the data item color
        fontSize: 14, // Set the font size
        fontWeight: 400, // Set the font weight
      },
      axisLine: {
        show: false, // Hide the xAxis line
      },
      type: "value",
      splitLine: {
        show: false,
        lineStyle: {
          type: "dashed",
        },
      },
    },
    series: [
      {
        symbol: "emptyCircle",
        symbolSize: 8,
        lineStyle: {
          width: 5,
          color: {
            type: "linear",
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: "#1F6D7A" }, // Start color
              { offset: 1, color: "#36917E" }, // End color
            ],
          },
        },
        data: data.resources_hit_per_month.hit_value,
        type: "line",
        smooth: true, // Enable smooth, curved line
      },
    ],
  };
  const donutChartOptionChannel = {
    title: {
      text: "Queries Status Rate",
      textStyle: {
        fontSize: 18,
        fontWeight: 400,
        color: "#030229",
      },
      left: "center",
      top: "top",
    },
    legend: {
      show: true,

      bottom: "bottom",
      icon: "circle",
      itemGap: 17, // Add space between legen
      textStyle: {
        color: "#030229", // Set the legend text color to white
        fontSize: 14,
        fontWeight: 400,
      },
    },

    series: [
      {
        center: ["50%", "50%"], // Center the chart with an offset of [10%, 20%]
        type: "pie",
        data: SUCCESS_FAIL_RATIO,
        radius: ["50%", "35%"],
        label: {
          show: true, // Hide the labels
          formatter: "{d}%",
          padding: 8,
          textStyle: {
            fontSize: 14,
            fontWeight: 400,
            color: "#000000",
          },
        },
        itemStyle: {
          borderRadius: 0, // Border radius for the chart portions
          borderWidth: 0,
          borderColor: "#000000",
        },
      },
    ],
  };
  const donutChartOptionEvent = {
    title: {
      text: "Database Types",
      textStyle: {
        fontSize: 18,
        fontWeight: 400,
        color: "#030229",
      },
      left: "center",
      top: "top",
    },
    legend: {
      show: true,

      bottom: "bottom",
      icon: "circle",
      itemGap: 17, // Add space between legen
      textStyle: {
        color: "#030229", // Set the legend text color to white
        fontSize: 14,
        fontWeight: 400,
      },
    },

    series: [
      {
        center: ["50%", "50%"], // Center the chart with an offset of [10%, 20%]
        type: "pie",
        data: DATABASE_TYPES,
        radius: ["50%", "35%"],
        label: {
          show: true,
          formatter: "{d}%",
          padding: 15,
          textStyle: {
            fontSize: 14,
            fontWeight: 400,
            color: "#000000",
          },
        },
        itemStyle: {
          borderRadius: 0, // Border radius for the chart portions
          borderWidth: 0,
          borderColor: "#000000",
        },
      },
    ],
  };
  return (
    <div className="bg-[#f4f7fd]">
      <div className="w-4/4 my-5 gap-4 rounded-lg bg-white p-[1.875rem]">
        <ReactEcharts option={salesBarChartData} />
      </div>
      <div className="w-4/4 flex flex-col items-center gap-4 md:flex-row">
        <div className="max-h-[371px] w-full rounded-lg bg-white p-[1.875rem] md:w-2/4">
          <ReactEcharts option={donutChartOptionEvent} />
        </div>
        <div className="max-h-[371px] w-full rounded-lg bg-white p-[1.875rem] md:w-2/4">
          <ReactEcharts option={donutChartOptionChannel} />
        </div>
      </div>
    </div>
  );
}
