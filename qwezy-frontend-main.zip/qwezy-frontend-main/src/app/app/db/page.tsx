"use client";

import {
  ExecuteQuery,
  GetDatabaseTableData,
  GetDatabaseTables,
} from "@/Client/request";
import { classNames } from "@/utils/classNames";
import { Empty, Input, Skeleton, Tooltip } from "antd";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useEffect, useState } from "react";
import SharedTable from "@/components/SharedTable/SharedTable";
import { UP_ICON, WARNING_ICON } from "@/constants/svg";
import { TableSkeleton } from "@/components/Skeltons/TableSkelton";
import { ChevronDoubleRightIcon, CogIcon } from "@heroicons/react/24/outline";
import { JsonView, allExpanded, darkStyles } from "react-json-view-lite";
import "react-json-view-lite/dist/index.css";

export default function Page() {
  //** states */
  const [tables, setTables] = useState<any>(null);
  const [tablesLoading, setTablesLoading] = useState(true);
  const [data, setData] = useState<any[]>([]); // Ensure data is an array
  const [dataLoading, setDataLoading] = useState(false);
  const [selectedTable, setSelectedTable] = useState("");
  const [columns, setColumns] = useState<any[]>([]); // Ensure columns is an array

  //** get db id */
  const search = useSearchParams();
  const id = search.get("id");

  //** router instance */
  const router = useRouter();

  function handleTableData(tableName: any) {
    setDataLoading(true);
    GetDatabaseTableData(id, tableName).then((res: any) => {
      if (res.data) {
        setData(res.data.data.records);
        const c = res.data.data.columns
          .map((column: string) => ({
            header: column.charAt(0).toUpperCase() + column.slice(1), // Capitalize the first letter
            accessorKey: column, // Use accessorKey for Material-React-Table
          }))
          .sort((a: any, b: any) => {
            // Sorting logic:
            const aKey = a.accessorKey.toLowerCase();
            const bKey = b.accessorKey.toLowerCase();

            if (aKey.includes("id") && !bKey.includes("id")) {
              return -1; // a comes first if it contains 'id'
            } else if (!aKey.includes("id") && bKey.includes("id")) {
              return 1; // b comes first if it contains 'id'
            }

            if (aKey.includes("at") && !bKey.includes("at")) {
              return 1; // a goes to the end if it contains 'at'
            } else if (!aKey.includes("at") && bKey.includes("at")) {
              return -1; // b goes to the end if it contains 'at'
            }

            return 0; // No sorting if neither contains 'id' or 'at'
          });
        setColumns(c);
      } else {
        alert("Cannot fetch data at the moment please try later");
      }
      setDataLoading(false);
    });
  }

  useEffect(() => {
    if (!id) {
      alert("Please select a database to continue");
      router.replace("/app/");
    }
  }, [id, router]);

  useEffect(() => {
    GetDatabaseTables(id).then((res: any) => {
      if (res.data) {
        setTables(res.data.tables);
      } else {
        setTables([]);
      }
      setTablesLoading(false);
    });
  }, [id]);

  return (
    <div className="database-layout relative h-[calc(100svh-4rem)] w-full overflow-x-hidden overflow-y-hidden">
      <div className="relative flex h-full w-full flex-col items-start justify-start lg:flex-row">
        <div className="z-[49] h-full w-full border-r bg-[white] lg:fixed lg:w-72">
          <div className="p-4">
            <h1 className="text-2xl">Tables</h1>
            <ul className="mt-5 flex flex-col gap-2">
              {tables &&
                tables.map((item: any, index: number) => (
                  <li
                    key={index}
                    onClick={() => {
                      setSelectedTable(item.tableName);
                      handleTableData(item.tableName);
                    }}
                    className={classNames(
                      "cursor-pointer rounded-lg px-3 py-2 opacity-55 hover:bg-gray-200 hover:opacity-100",
                      selectedTable === item.tableName &&
                        "bg-gray-200 opacity-100",
                    )}
                  >
                    {item.tableName}
                  </li>
                ))}
              {!tables && tablesLoading && (
                <>
                  <Skeleton active />
                  <Skeleton active />
                </>
              )}
            </ul>
          </div>
        </div>
        <div className="relative h-full w-full overflow-x-hidden bg-[#F2F4F8] pb-10 lg:ml-72">
          {!dataLoading && data.length > 0 && columns.length > 0 && (
            <SharedTable data={data} columns={columns} />
          )}
          {data.length === 0 && (
            <div className="flex h-full w-full items-center justify-center">
              {!dataLoading && (
                <Empty description="Select a table to view data" />
              )}
              {dataLoading && <TableSkeleton />}
            </div>
          )}
        </div>
        {!dataLoading && data.length > 0 && columns.length > 0 && (
          <QueryPanel id={id} />
        )}
      </div>
    </div>
  );
}

function QueryPanel({ id }: { id: any }) {
  const [isOpen, setIsOpen] = useState(false);
  const [data, setData] = useState<any>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);

  function handleQuerySubmit() {
    if (query === "") {
      return;
    }

    setData((prev: any) => [...prev, { type: "user", data: query }]);
    setLoading(true);
    setQuery("");
    ExecuteQuery({ query }, id).then((res: any) => {
      if (res.data) {
        setData((prev: any) => [...prev, { type: "system", data: res.data }]);
      } else {
        console.log(res.error.response);
        setData((prev: any) => [
          ...prev,
          { type: "error", data: res.error.response.data.message },
        ]);
      }
      setLoading(false);
    });
  }

  return (
    <div
      className={classNames(
        "absolute -bottom-1 right-0 z-[50] flex w-full max-w-full flex-col items-center justify-start border-t transition-all",
        isOpen ? "h-1/2 bg-gray-50" : "h-9",
      )}
    >
      <div
        className="flex w-full cursor-pointer items-center justify-center bg-white hover:bg-gray-50"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div
          className={classNames(
            isOpen && "rotate-180 text-primary",
            "py-2 transition-all duration-300",
          )}
        >
          {UP_ICON}
        </div>
      </div>
      <div className="relative flex h-full w-full flex-col items-start justify-start px-3">
        <div className="w-full overflow-x-hidden overflow-y-scroll">
          <div className="mt-3">
            <div className="flex gap-2">
              <h2 className="text-lg">Query Panel</h2>
              <Tooltip
                title={
                  "Dangerous write queries like DROP, INSERT and UPDATE are not allowed. Only read-based queries are allowed."
                }
              >
                {WARNING_ICON}
              </Tooltip>
            </div>
            <p className="text-sm opacity-55">
              Execute SQL-based queries and view results in real-time{" "}
            </p>
          </div>
          <div className="flex w-full flex-col gap-3 pb-24 pt-3">
            {data.map((item: any, index: number) => {
              return item.type === "user" ? (
                <div
                  key={index}
                  className="text-ellipsis rounded border bg-white px-2 py-2"
                >
                  <div className="flex items-center text-sm">
                    <ChevronDoubleRightIcon className="size-5" />
                    {item.data}
                  </div>
                </div>
              ) : (
                <div
                  key={index}
                  className={classNames(
                    "flex items-start justify-between text-ellipsis rounded px-2 py-2",
                    item.data.status === "success"
                      ? "border border-primary bg-primary bg-opacity-10"
                      : (item.data.status === "failed" ||
                          item.type === "error") &&
                          "border border-red-500 bg-red-500 bg-opacity-10",
                  )}
                >
                  <div className="flex items-center text-sm">
                    <ChevronDoubleRightIcon className="size-5" />
                    {item.data.status === "failed" ? (
                      item.data.errorMessage
                    ) : item.type === "error" ? (
                      item.data
                    ) : (
                      <JsonView
                        data={item.data.result}
                        shouldExpandNode={allExpanded}
                        style={darkStyles}
                      />
                    )}
                  </div>
                  <div>
                    <p className="text-sm">{item.data.executionTime} s</p>
                  </div>
                </div>
              );
            })}
            {loading && (
              <div className="rounded border bg-white px-2 py-2">
                Loading...
              </div>
            )}
          </div>
        </div>
      </div>
      {isOpen && (
        <div className="absolute bottom-0 left-0 w-full">
          <Input
            prefix={<CogIcon className="size-5" />}
            className="h-12 !rounded-none !border-0 !border-t"
            placeholder="Enter your SQL query..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleQuerySubmit();
              }
            }}
          />
        </div>
      )}
    </div>
  );
}
