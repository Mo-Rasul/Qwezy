"use client";

import React, { useEffect, useState, useRef } from "react";
import { Button, Input, Skeleton, Spin } from "antd";

import {
  Cog6ToothIcon,
  LightBulbIcon,
  PaperAirplaneIcon,
} from "@heroicons/react/24/outline";
import { ChatWithBot, GetChatHistory } from "@/Client/request";
import moment from "moment";
import { classNames } from "@/utils/classNames";
import { MarkdownRenderer } from "@/components/Chatbot/MardownRenderer";
import { Logo } from "@/components/Logo";
import { useAuth } from "@/hooks/useAuth";

export default function Page() {
  const [messages, setMessages] = useState<any>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [masterLoading, setMasterLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  //** auth */
  const auth = useAuth();

  const handleSendMessage = (premade?: string) => {
    if (premade) {
      handlePrompt(premade);
    } else {
      handlePrompt(input);
    }
  };

  const handlePrompt = (prompt: string) => {
    if (prompt.trim()) {
      setLoading(true);
      setMessages((prevMessages: any) => [
        ...prevMessages,
        {
          role: "user",
          content: prompt,
          createdAt: moment().unix(),
        },
      ]);
      ChatWithBot({ query: prompt }).then((res: any) => {
        if (res.data) {
          setMessages(res.data.reverse());
        }
        setLoading(false);
      });
      setInput("");
    }
  };

  useEffect(() => {
    GetChatHistory().then((res: any) => {
      if (res.data) {
        setMessages(res.data.reverse());
      }
      setMasterLoading(false);
    });
  }, []);

  // Scroll to bottom whenever messages update
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div className="chats">
      <div
        className={classNames(
          "relative flex min-h-[calc(100svh-60px)] w-full flex-col bg-white transition-all duration-300",
        )}
      >
        {masterLoading ? (
          <div className="container mt-10 flex flex-col gap-4">
            <Skeleton active />
            <Skeleton active />
            <Skeleton active />
          </div>
        ) : (
          <>
            <div className="container h-full overflow-y-auto">
              {messages.length === 0 && !loading && (
                <div className="flex min-h-[calc(100svh-200px)] w-full flex-col items-center justify-center gap-4">
                  <Logo height={100} width={100} />
                  <h4 className="text-xl font-semibold text-primary">
                    Lets find a solution togethor
                  </h4>
                  <div
                    onClick={() => handleSendMessage("Teach me about SQL")}
                    className="flex flex-wrap items-center justify-center gap-4"
                  >
                    <div className="flex w-full cursor-pointer flex-row gap-2 rounded-xl border bg-gray-50 p-5 transition-all hover:border-primary md:w-80">
                      <LightBulbIcon className="size-6 text-orange-400" />
                      <p className="opacity-55">Teach me about SQL</p>
                    </div>
                    <div
                      onClick={() =>
                        handleSendMessage("Write me an insert query")
                      }
                      className="flex w-full cursor-pointer flex-row gap-2 rounded-xl border bg-gray-50 p-5 transition-all hover:border-primary md:w-80"
                    >
                      <Cog6ToothIcon className="size-6 text-purple-400" />
                      <p className="opacity-55">Write me an insert query</p>
                    </div>
                  </div>
                </div>
              )}
              <div className="mb-10 mt-5 flex w-full flex-col gap-3">
                {messages.map((msg: any, index: number) =>
                  msg.role === "user" ? (
                    <div
                      key={index}
                      className="flex w-full flex-col items-end justify-end"
                    >
                      <div className="w-fit rounded-xl bg-primary p-4 text-sm text-white">
                        {msg.content}
                      </div>
                      <p className="my-3 text-xs opacity-55">
                        {moment.unix(msg.createdAt).fromNow()}
                      </p>
                    </div>
                  ) : (
                    <div
                      key={index}
                      className="flex w-full flex-col items-start justify-start"
                    >
                      <div className="w-fit break-words rounded-xl bg-background p-4 text-sm text-black">
                        <MarkdownRenderer content={msg.content} />
                      </div>
                      <p className="my-3 text-xs opacity-55">
                        {moment.unix(msg.createdAt).fromNow()}
                      </p>
                    </div>
                  ),
                )}
                {loading && (
                  <div className="flex w-full animate-pulse flex-col items-start justify-start">
                    <div className="w-fit rounded-xl bg-gray-200 p-3 text-sm text-gray-500">
                      Thinking{"        "}
                      <span>
                        <Spin />
                      </span>
                    </div>
                  </div>
                )}
                {/* This div is used to scroll to the bottom */}
                <div ref={messagesEndRef} />
              </div>
            </div>
            <div
              className={classNames(
                "z-1 fixed bottom-5 left-0 flex w-full items-center justify-center transition-all",
                auth.isCollapsed ? "lg:ml-5" : "lg:ml-40",
              )}
            >
              <div className="flex w-[35rem] gap-2 rounded-full border bg-white px-7 py-3 shadow-2xl">
                <Input
                  className="mr-2 flex-1 !border-none !ring-0"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type your problem here..."
                  onPressEnter={() => handleSendMessage()}
                />
                <Button type="primary" onClick={() => handleSendMessage()}>
                  <PaperAirplaneIcon className="size-6 text-white" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
