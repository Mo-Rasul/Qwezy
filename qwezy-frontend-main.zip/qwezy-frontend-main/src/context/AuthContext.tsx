"use client";

// ** React Imports
import { createContext, useEffect, useState, ReactNode } from "react";

// ** Next Import
import { useRouter } from "next/navigation";

import ls from "localstorage-slim";

// ** Axios
import axios from "axios";

// ** Types
import {
  AuthValuesType,
  RegisterParams,
  LoginParams,
  UserDataType,
} from "./types";

import moment from "moment";
import { authConfig } from "@/configs/api";
import { toast } from "react-toastify";
import { Logout } from "@/Client/request";

// ** Defaults
const defaultProvider: AuthValuesType = {
  user: null,
  loading: true,
  settings: null,
  isCollapsed: true,
  setUser: () => null,
  setLoading: () => Boolean,
  setSettings: () => null,
  login: () => Promise.resolve(),
  logout: () => Promise.resolve(),
  register: () => Promise.resolve(),
  initAuth: () => Promise.resolve(),
  RefreshInformation: () => Promise.resolve(),
  loginTeam: () => Promise.resolve(),
  setIsCollapsed: () => null,
};

const AuthContext = createContext(defaultProvider);

type Props = {
  children: ReactNode;
};

const AuthProvider = ({ children }: Props) => {
  // ** States
  const [user, setUser] = useState<UserDataType | null>(defaultProvider.user);
  const [loading, setLoading] = useState<boolean>(defaultProvider.loading);
  const [settings, setSettings] = useState<object | null>(
    defaultProvider.settings,
  );
  const [isCollapsed, setIsCollapsed] = useState(defaultProvider.isCollapsed);

  // ** Hooks
  const router = useRouter();

  const initAuth = async () => {
    setLoading(true);
    const storedToken1: any = window.localStorage.getItem(
      authConfig.storageTokenKeyName,
    );
    const storedToken2 = JSON.parse(storedToken1);
    const userDataCheck: any = ls.get("userData", { encrypt: true });
    if (storedToken2) {
      setLoading(true);
      if (isLoggedIn()) {
        setUser(userDataCheck);
      } else {
        console.log("Logout due to token expiry!");
        toast.success("Logout due to session expirey!");
        handleLogout();
      }
      setLoading(false);
    } else {
      setLoading(false);
    }
  };

  const RefreshInformation = (data: any) => {
    parseLoginResponse({ data: { user: data } }, true);
  };

  function parseLoginResponse(
    response: any,
    onlyInfromation: boolean,
    team?: boolean,
  ) {
    const res = team
      ? { ...response.data.team, name: response.data.team.firstName }
      : { ...response.data.user };

    console.log(res);

    if (!onlyInfromation) {
      const token = response.data.tokens.access;
      const refreshToken = response.data.tokens.refresh;
      const tokenData = {
        token: token.token,
        expiry: token.expires,
      };
      const refreshData = {
        token: refreshToken.token,
        expiry: refreshToken.expires,
      };

      window.localStorage.setItem(
        authConfig.storageTokenKeyName,
        JSON.stringify(tokenData),
      );
      window.localStorage.setItem(
        authConfig.refreshStorageTokenKeyName,
        JSON.stringify(refreshData),
      );
    }

    const userData: any = res;
    ls.set("userData", userData, { encrypt: true });
    setUser(userData);
    setLoading(false);
    initAuth();
    !onlyInfromation && router.replace("/app/");
  }

  useEffect(() => {
    // Axios305Interceptor(handleLogout, user);
    initAuth();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleLogin = (
    params: LoginParams,
    errorCallback: any,
    setLoading?: any,
  ) => {
    axios
      .post(authConfig.loginEndpoint, {
        email: params.email,
        password: params.password,
      })
      .then((response: any) => {
        parseLoginResponse(response, false);
      })
      .catch((err) => {
        setLoading(false);
        if (errorCallback) errorCallback(err.response.data.message);
      });
  };
  const handleLoginTeam = (
    params: LoginParams,
    errorCallback: any,
    setLoading?: any,
  ) => {
    axios
      .post(authConfig.loginEndpointTeam, {
        email: params.email,
        password: params.password,
      })
      .then((response: any) => {
        parseLoginResponse(response, false, true);
      })
      .catch((err) => {
        setLoading(false);
        if (errorCallback) errorCallback(err.response.data.message);
      });
  };

  const handleLogout = () => {
    setLoading(true);
    Logout().then(() => {
      setLoading(false);

      setUser(null);
      ls.remove("userData");
      window.localStorage.removeItem(authConfig.storageTokenKeyName);
      router.replace("/auth/login/");
    });
  };

  function isLoggedIn() {
    return moment().isBefore(getExpirationAccessToken());
  }
  function getExpirationAccessToken() {
    const expiration1: any = localStorage.getItem(
      authConfig.storageTokenKeyName,
    );
    const expiration = JSON.parse(expiration1);
    if (expiration1) {
      const expiresAt = expiration.expiry || "{}";

      return moment(expiresAt);
    } else {
      return null;
    }
  }
  const handleRegister = (
    params: RegisterParams,
    errorCallback: any,
    setLoading: any,
  ) => {
    axios
      .post(authConfig.registerEndpoint, {
        email: params.email,
        password: params.password,
        name: params.name,
        phone: params.phone,
      })
      .then((res: any) => {
        parseLoginResponse(res, false);
      })
      .catch((err: any) => {
        setLoading(false);
        errorCallback ? errorCallback(err.response.data.message) : null;
      });
  };
  const values = {
    user,
    loading,
    settings,
    setUser,
    setLoading,
    setSettings,
    login: handleLogin,
    logout: handleLogout,
    register: handleRegister,
    initAuth,
    RefreshInformation,
    loginTeam: handleLoginTeam,
    setIsCollapsed,
    isCollapsed,
  };

  return <AuthContext.Provider value={values}>{children}</AuthContext.Provider>;
};

export { AuthContext, AuthProvider };
