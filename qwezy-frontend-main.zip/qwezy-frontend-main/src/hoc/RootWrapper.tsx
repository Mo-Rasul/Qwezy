"use client";

import AuthGuard from "@/guards/AuthGuard";
import FallbackSpinner from "@/components/spinner/FallbackSpinner";
import React from "react";
import { usePathname } from "next/navigation";
import { AppProgressBar } from "next-nprogress-bar";
import RoleGuard from "@/guards/RoleGuard";
import AppLayout from "@/layouts/AppLayout";
import { AuthProvider } from "@/context/AuthContext";

export default function RootWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const getLayout = pathname.includes("app") ? (
    <AuthGuard fallback={<FallbackSpinner />}>
      <RoleGuard fallback={<FallbackSpinner />}>
        <AppLayout>{children}</AppLayout>
      </RoleGuard>
    </AuthGuard>
  ) : pathname.includes("auth") ? (
    <AuthGuard fallback={<FallbackSpinner />}>{children}</AuthGuard>
  ) : (
    children
  );
  return (
    <>
      <AppProgressBar
        height="3px"
        color="#01c68e"
        options={{ showSpinner: false }}
      />
      <AuthProvider>{getLayout}</AuthProvider>
    </>
  );
}
