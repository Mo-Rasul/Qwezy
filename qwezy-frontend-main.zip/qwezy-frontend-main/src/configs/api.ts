export const API_URL =
  "http://qwezy-backend-env.eba-9p7enkbm.eu-west-1.elasticbeanstalk.com/v1";

// export const API_URL = "http://localhost:3000/v1";

export const authConfig = {
  loginEndpoint: API_URL + "/auth/login",
  loginEndpointTeam: API_URL + "/team/login",
  loginEndpointGoogle: API_URL + "login",
  storageTokenKeyName: "accessToken",
  refreshStorageTokenKeyName: "refreshToken",
  registerEndpoint: API_URL + "/auth/register",
  logoutEndpoint: API_URL + "/auth/logout",
  updateUserEndpoint: API_URL + "/users",
  updateUserPassword: API_URL + "/users/update-password",
};
