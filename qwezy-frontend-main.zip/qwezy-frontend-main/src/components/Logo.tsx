import Image from "next/image";

export function Logo({ height, width }: { height?: number; width?: number }) {
  return (
    <div className="flex gap-4">
      <Image
        src={"/logo.png"}
        alt="Qwezy Logo"
        height={height ?? 50}
        width={width ?? 50}
      />
    </div>
  );
}
