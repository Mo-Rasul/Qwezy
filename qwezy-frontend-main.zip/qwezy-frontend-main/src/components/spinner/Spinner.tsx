// import clsx from "clsx";
import Image from "next/image";

// interface Props {
//   size?: string | number;
//   color?: string;
// }

const Spinner = () => {
  return <Image src="/spinner.svg" height={100} width={100} alt="spinner" />;
};

export default Spinner;
