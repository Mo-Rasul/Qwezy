"use client";

import React, { useEffect, useState, useRef } from "react";
import { Button, Input, Spin } from "antd";
import { MessageOutlined, CloseOutlined } from "@ant-design/icons";
import {
  ArrowsPointingOutIcon,
  PaperAirplaneIcon,
} from "@heroicons/react/24/outline";
import { ChatWithBot, GetChatHistory } from "@/Client/request";
import moment from "moment";
import { classNames } from "@/utils/classNames";
import { MarkdownRenderer } from "./MardownRenderer";

const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<any>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const handleSendMessage = () => {
    if (input.trim()) {
      setLoading(true);
      setMessages((prevMessages: any) => [
        ...prevMessages,
        {
          role: "user",
          content: input,
          createdAt: moment().unix(),
        },
      ]);
      ChatWithBot({ query: input }).then((res: any) => {
        if (res.data) {
          setMessages(res.data.reverse());
        }
        setLoading(false);
      });
      setInput("");
    }
  };

  useEffect(() => {
    GetChatHistory().then((res: any) => {
      if (res.data) {
        setMessages(res.data.reverse());
      }
      setLoading(false);
    });
  }, []);

  // Scroll to bottom whenever messages update
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div className="fixed bottom-5 right-5 z-[1100]">
      <Button
        onClick={toggleChat}
        type="primary"
        shape="circle"
        icon={<MessageOutlined />}
        className="!size-12 rounded-full"
      />
      {isOpen && (
        <div
          className={classNames(
            "fixed bottom-20 right-5 z-50 flex flex-col rounded-lg bg-white shadow-2xl transition-all duration-300",
            isFullScreen ? "h-[85%] w-[91%] md:w-[90%]" : "h-[35rem] w-[30rem]",
          )}
        >
          <div className="flex items-center justify-between rounded-t-lg bg-primary p-4 text-white">
            <span>Qwezy AI</span>
            <div className="flex items-center justify-center gap-2">
              <div
                className="cursor-pointer"
                onClick={() => setIsFullScreen(!isFullScreen)}
              >
                <ArrowsPointingOutIcon className="size-6 text-white" />
              </div>
              <Button
                onClick={toggleChat}
                shape="circle"
                icon={<CloseOutlined />}
              />
            </div>
          </div>

          <div className="flex-1 gap-3 overflow-y-auto p-3">
            {messages.map((msg: any, index: number) =>
              msg.role === "user" ? (
                <div
                  key={index}
                  className="flex w-full flex-col items-end justify-end"
                >
                  <div className="w-fit rounded-xl bg-primary p-3 text-sm text-white">
                    {msg.content}
                  </div>
                  <p className="my-3 text-xs opacity-55">
                    {moment.unix(msg.createdAt).fromNow()}
                  </p>
                </div>
              ) : (
                <div
                  key={index}
                  className="flex w-full flex-col items-start justify-start"
                >
                  <div className="w-fit break-words rounded-xl bg-background p-3 text-sm text-black">
                    <MarkdownRenderer content={msg.content} />
                  </div>
                  <p className="my-3 text-xs opacity-55">
                    {moment.unix(msg.createdAt).fromNow()}
                  </p>
                </div>
              ),
            )}
            {loading && (
              <div className="flex w-full animate-pulse flex-col items-start justify-start">
                <div className="w-fit rounded-xl bg-gray-200 p-3 text-sm text-gray-500">
                  Thinking{"        "}
                  <span>
                    <Spin />
                  </span>
                </div>
              </div>
            )}
            {/* This div is used to scroll to the bottom */}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="flex gap-2 border-t border-gray-200 p-4">
            <Input
              className="mr-2 flex-1"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              onPressEnter={handleSendMessage}
            />
            <Button type="primary" onClick={handleSendMessage}>
              <PaperAirplaneIcon className="size-6 text-white" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatBot;
