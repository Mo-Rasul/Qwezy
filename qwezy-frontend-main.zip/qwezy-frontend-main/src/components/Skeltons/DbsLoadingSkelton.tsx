import React from "react";

export const DbsLoadingSkelton = () => {
  const numberOfItems = new Array(10).fill(null);

  return (
    <div className="flex flex-wrap items-center justify-start gap-2">
      {numberOfItems.map((_, index) => (
        <div
          key={index}
          className="flex animate-pulse cursor-pointer items-center justify-start gap-4 rounded-lg border bg-white px-5 py-5"
        >
          {/* Skeleton for Image */}
          <div className="h-[80px] w-[80px] animate-pulse rounded bg-gray-200"></div>

          <div className="flex flex-col gap-2">
            {/* Skeleton for Title */}
            <div className="h-6 w-40 animate-pulse rounded bg-gray-200"></div>

            {/* Skeleton for Date */}
            <div className="h-4 w-32 animate-pulse rounded bg-gray-200 opacity-40"></div>
          </div>
        </div>
      ))}
    </div>
  );
};
