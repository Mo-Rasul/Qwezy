import React from "react";

export const TableSkeleton = () => {
  const rows = new Array(18).fill(null);
  const columns = new Array(5).fill(null);

  return (
    <div className="h-full w-full overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            {columns.map((_, index) => (
              <th
                key={index}
                className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500"
              >
                <div className="h-4 w-3/4 animate-pulse rounded bg-gray-300"></div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 bg-white">
          {rows.map((_, rowIndex) => (
            <tr key={rowIndex}>
              {columns.map((_, colIndex) => (
                <td key={colIndex} className="whitespace-nowrap px-6 py-4">
                  <div className="h-4 w-full animate-pulse rounded bg-gray-300"></div>
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
