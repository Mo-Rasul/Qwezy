import React from "react";
import { MaterialReactTable } from "material-react-table";

interface TableProps {
  columns: Array<{ header: string; accessorKey: string }>;
  data: Array<any>;
}

const SharedTable: React.FC<TableProps> = ({ columns, data }) => {
  return (
    <MaterialReactTable
      columns={columns}
      data={data}
      enableColumnResizing
      enablePagination
      muiTablePaperProps={{
        sx: {
          boxShadow: "none", // Removes the default shadow
          fontFamily: "Poppins, sans-serif", // Set Poppins as default font
        },
      }}
      muiTableContainerProps={{
        sx: {
          fontFamily: "Poppins, sans-serif", // Ensure font is applied to the container
        },
      }}
    />
  );
};

export default SharedTable;
