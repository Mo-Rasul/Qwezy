import { API_URL, authConfig } from "@/configs/api";
import axios from "axios";

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const GetTokenAsync = () => {
  const storedToken = window.localStorage.getItem(
    authConfig.storageTokenKeyName,
  );

  return storedToken ? JSON.parse(storedToken).token : null;
};
const GetRefreshTokenAsync = () => {
  const storedToken = window.localStorage.getItem(
    authConfig.refreshStorageTokenKeyName,
  );

  return storedToken ? JSON.parse(storedToken).token : null;
};

export async function Logout() {
  const token = GetRefreshTokenAsync();
  const config = {
    method: "post",
    url: API_URL + "/auth/logout",
    data: {
      refreshToken: token,
    },
  };

  return axios(config)
    .then(() => {
      return { data: true };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function GetDatabases() {
  const token = GetTokenAsync();
  const config = {
    method: "get",
    url: API_URL + "/db/",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function AddDatabase(payload: any) {
  const token = GetTokenAsync();
  const config = {
    method: "post",
    url: API_URL + "/db/add-database",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: payload,
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function UpdateDatabase(payload: any, id: string) {
  const token = GetTokenAsync();
  const config = {
    method: "put",
    url: API_URL + "/db/" + id,
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: payload,
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}

export async function TestConnection(payload: any) {
  delete payload.name;
  const token = GetTokenAsync();
  const config = {
    method: "post",
    url: API_URL + "/db/test-connection",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: payload,
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}

export async function DeleteDatabase(id: string) {
  const token = GetTokenAsync();
  const config = {
    method: "Delete",
    url: API_URL + "/db/" + id,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function GetDatabaseTables(id: any) {
  const token = GetTokenAsync();
  const config = {
    method: "get",
    url: API_URL + "/db/tables/" + id,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function GetDatabaseTableData(dbId: any, tableName: string) {
  const token = GetTokenAsync();
  const config = {
    method: "get",
    url: API_URL + "/db/tables/" + dbId + "/" + tableName,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function ExecuteQuery(payload: any, id: string) {
  delete payload.name;
  const token = GetTokenAsync();
  const config = {
    method: "post",
    url: API_URL + "/db/execute-query/" + id,
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: payload,
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function GetStatistics() {
  const token = GetTokenAsync();
  const config = {
    method: "get",
    url: API_URL + "/statistics/",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function GetChatHistory() {
  const token = GetTokenAsync();
  const config = {
    method: "get",
    url: API_URL + "/bot/",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
export async function ChatWithBot(payload: any) {
  delete payload.name;
  const token = GetTokenAsync();
  const config = {
    method: "post",
    url: API_URL + "/bot/",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    data: payload,
  };

  return axios(config)
    .then((response) => {
      return { data: response.data };
    })
    .catch((error) => {
      return { error: error };
    });
}
