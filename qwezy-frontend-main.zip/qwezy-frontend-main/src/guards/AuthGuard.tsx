"use client";

// ** React Imports
import { ReactNode, ReactElement, useEffect } from "react";

// ** Next Import
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";

// ** Hooks Import

interface AuthGuardProps {
  children: ReactNode;
  fallback: ReactElement | null;
}

const AuthGuard = (props: AuthGuardProps) => {
  const { children, fallback } = props;
  const auth = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const userData = window.localStorage.getItem("userData");

    if (auth.loading) {
      return;
    }

    if (auth.user === null && !userData) {
      if (
        pathname !== "/auth/login/" &&
        pathname !== "/auth/register/" &&
        pathname !== "/auth/forget-password/"
      ) {
        router.replace("/auth/login");
      }
    } else {
      if (
        pathname === "/auth/login/" ||
        pathname === "/auth/create-account/" ||
        pathname === "/auth/forget-password/"
      ) {
        router.replace("/app");
      }
    }
  }, [auth.loading, auth.user, pathname, router]);

  if (auth.loading) {
    return fallback;
  }

  return <>{children}</>;
};

export default AuthGuard;
