"use client";

// ** React Imports
import { ReactNode, ReactElement } from "react";

// ** Next Import
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "react-toastify";

// ** Hooks Import

interface RoleGuardProps {
  children: ReactNode;
  fallback: ReactElement | null;
}

const RoleGuard = (props: RoleGuardProps) => {
  const { children, fallback } = props;
  const auth = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  if (auth.loading) {
    return fallback;
  }

  if (auth.user?.role === "team") {
    if (
      pathname.includes("team") ||
      pathname.includes("settings") ||
      pathname.includes("kpi") ||
      pathname.includes("subscription")
    ) {
      toast.warning("You are not allowed to visit this page");
      router.replace("/app/");
      return fallback;
    }
  }

  return <>{children}</>;
};

export default RoleGuard;
