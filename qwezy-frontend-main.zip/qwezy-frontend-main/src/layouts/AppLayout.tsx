"use client";

import { useState } from "react";
import {
  Dialog,
  DialogBackdrop,
  DialogPanel,
  Menu,
  MenuButton,
  TransitionChild,
} from "@headlessui/react";
import {
  ArrowRightStartOnRectangleIcon,
  Bars3Icon,
  ChevronLeftIcon,
  ChevronRightIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { MagnifyingGlassIcon } from "@heroicons/react/20/solid";
import { Logo } from "@/components/Logo";
import { navigation } from "@/constants/Navigations";
import { useAuth } from "@/hooks/useAuth";
import { usePathname } from "next/navigation";
import Link from "next/link";
import ChatBot from "@/components/Chatbot/chatbot";

function classNames(...classes: any) {
  return classes.filter(Boolean).join(" ");
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  //** auth */
  const auth = useAuth();

  //** router */
  const pathname = usePathname();

  return (
    <>
      <div className="app-layout min-h-svh">
        {pathname !== "/app/chat/" && <ChatBot />}
        <Dialog
          open={sidebarOpen}
          onClose={setSidebarOpen}
          className="relative z-50 lg:hidden"
        >
          <DialogBackdrop
            transition
            className="fixed inset-0 bg-gray-900/80 transition-opacity duration-300 ease-linear data-[closed]:opacity-0"
          />

          <div className="fixed inset-0 flex">
            <DialogPanel
              transition
              className="relative mr-16 flex w-full max-w-xs flex-1 transform transition duration-300 ease-in-out data-[closed]:-translate-x-full"
            >
              <TransitionChild>
                <div className="absolute left-full top-0 flex w-16 justify-center pt-5 duration-300 ease-in-out data-[closed]:opacity-0">
                  <button
                    type="button"
                    onClick={() => setSidebarOpen(false)}
                    className="-m-2.5 p-2.5"
                  >
                    <span className="sr-only">Close sidebar</span>
                    <XMarkIcon
                      aria-hidden="true"
                      className="h-5 w-5 text-white"
                    />
                  </button>
                </div>
              </TransitionChild>
              {/* Sidebar component, swap this element with another sidebar if you like */}
              <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white px-6 pb-4">
                <div className="flex h-16 shrink-0 items-center gap-2">
                  <Logo />
                  <h2 className="text-xl font-semibold text-primary">Qwezy</h2>
                </div>
                <nav className="flex flex-1 flex-col">
                  <ul role="list" className="flex flex-1 flex-col gap-y-7">
                    <li>
                      <ul role="list" className="-mx-2 space-y-1">
                        {navigation.map((item) => (
                          <li key={item.name}>
                            <Link
                              href={item.href}
                              className={classNames(
                                pathname === item.href
                                  ? "bg-gray-50 text-primary"
                                  : "text-gray-700 hover:bg-gray-50 hover:text-primary",
                                "group flex gap-x-3 rounded-md p-2 text-sm font-semibold leading-6",
                              )}
                            >
                              <item.icon
                                aria-hidden="true"
                                className={classNames(
                                  pathname === item.href
                                    ? "text-primary"
                                    : "text-gray-400 group-hover:text-primary",
                                  "h-5 w-5 shrink-0",
                                )}
                              />
                              {item.name}
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </li>
                    <li className="mt-auto">
                      <a
                        onClick={() => auth.logout()}
                        className="group -mx-2 flex cursor-pointer gap-x-3 rounded-md p-2 text-sm font-semibold leading-6 text-gray-700 hover:bg-gray-50 hover:text-primary"
                      >
                        <ArrowRightStartOnRectangleIcon
                          aria-hidden="true"
                          className="h-5 w-5 shrink-0 text-gray-400 group-hover:text-primary"
                        />
                        Logout
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </DialogPanel>
          </div>
        </Dialog>

        {/* Static sidebar for desktop */}
        <div
          className={classNames(
            "hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:flex-col",
            auth.isCollapsed ? "lg:w-20" : "lg:w-72",
          )}
        >
          {/* Sidebar component, swap this element with another sidebar if you like */}
          <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-gradient-to-b from-primary to-secondary px-6 pb-4">
            <div
              className={classNames(
                "mt-4 flex h-14 gap-2",
                auth.isCollapsed ? "-mx-1 items-start" : "items-center",
              )}
            >
              <Logo />
              {!auth.isCollapsed && (
                <h2 className="text-xl font-semibold text-white">Qwezy</h2>
              )}
            </div>
            <nav className="flex flex-1 flex-col">
              <ul role="list" className="flex flex-1 flex-col gap-y-7">
                <li>
                  <ul role="list" className="-mx-2 space-y-1">
                    {navigation.map((item) => (
                      <li key={item.name}>
                        <Link
                          href={item.href}
                          className={classNames(
                            "transition-all duration-300",
                            pathname === item.href
                              ? "bg-gray-50 text-primary"
                              : "text-white hover:bg-gray-50 hover:bg-opacity-75 hover:text-primary",
                            auth.isCollapsed
                              ? "group flex items-center justify-center gap-x-3 rounded-md p-2 text-sm font-semibold leading-6"
                              : "group flex gap-x-3 rounded-md p-2 text-sm font-semibold leading-6",
                          )}
                        >
                          <item.icon
                            aria-hidden="true"
                            className={classNames(
                              pathname === item.href
                                ? "text-primary"
                                : "text-white group-hover:text-primary",
                              "h-5 w-5 shrink-0",
                            )}
                          />
                          {!auth.isCollapsed && item.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </li>

                <li className="mt-auto">
                  <a
                    onClick={() => auth.setIsCollapsed(!auth.isCollapsed)}
                    className={classNames(
                      "group -mx-2 flex cursor-pointer gap-x-3 rounded-md p-2 text-sm font-semibold leading-6 text-white transition-all duration-300 hover:bg-gray-50 hover:bg-opacity-75 hover:text-primary",
                      auth.isCollapsed && "items-center justify-center",
                    )}
                  >
                    {auth.isCollapsed ? (
                      <ChevronRightIcon
                        aria-hidden="true"
                        className="h-5 w-5 shrink-0 text-white group-hover:text-primary"
                      />
                    ) : (
                      <>
                        <ChevronLeftIcon
                          aria-hidden="true"
                          className="h-5 w-5 shrink-0 text-white group-hover:text-primary"
                        />
                        Collapse
                      </>
                    )}
                  </a>
                  <a
                    onClick={() => auth.logout()}
                    className={classNames(
                      "group -mx-2 flex cursor-pointer gap-x-3 rounded-md p-2 text-sm font-semibold leading-6 text-white transition-all duration-300 hover:bg-gray-50 hover:bg-opacity-75 hover:text-primary",
                      auth.isCollapsed && "items-center justify-center",
                    )}
                  >
                    <ArrowRightStartOnRectangleIcon
                      aria-hidden="true"
                      className="h-5 w-5 shrink-0 text-white group-hover:text-primary"
                    />
                    {!auth.isCollapsed && "Logout"}
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div>

        <div
          className={classNames(
            auth.isCollapsed ? "lg:pl-20" : "lg:pl-72",
            "w-full",
          )}
        >
          <div
            className={classNames(
              "fixed top-0 z-[50] border-b border-gray-200",
              auth.isCollapsed
                ? "w-full lg:w-[calc(100%-5rem)]"
                : "w-full lg:w-[calc(100%-18rem)]",
            )}
          >
            <div className="flex h-16 items-center gap-x-4 bg-white px-4 shadow-sm lg:shadow-none">
              <button
                type="button"
                onClick={() => setSidebarOpen(true)}
                className="-m-2.5 p-2.5 text-gray-700 lg:hidden"
              >
                <span className="sr-only">Open sidebar</span>
                <Bars3Icon aria-hidden="true" className="h-5 w-5" />
              </button>

              {/* Separator */}
              <div
                aria-hidden="true"
                className="h-6 w-px bg-gray-200 lg:hidden"
              />

              <div className="flex flex-1 gap-x-4 self-stretch lg:gap-x-6">
                <form action="#" method="GET" className="relative flex flex-1">
                  <label htmlFor="search-field" className="sr-only">
                    Search
                  </label>
                  <MagnifyingGlassIcon
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-y-0 left-0 h-full w-5 text-gray-400"
                  />
                  <input
                    id="search-field"
                    name="search"
                    type="search"
                    placeholder="Search..."
                    className="block h-full w-full border-0 py-0 pl-8 pr-0 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm"
                  />
                </form>
                <div className="flex items-center gap-x-4 lg:gap-x-6">
                  <div
                    aria-hidden="true"
                    className="hidden lg:block lg:h-6 lg:w-px lg:bg-gray-200"
                  />
                  <Menu as="div" className="relative">
                    <MenuButton className="flex items-center">
                      <span className="hidden lg:flex lg:items-center">
                        <span
                          aria-hidden="true"
                          className="text-sm font-semibold leading-6 text-gray-900"
                        >
                          {auth.user?.name}
                        </span>
                      </span>
                    </MenuButton>
                  </Menu>
                </div>
              </div>
            </div>
          </div>

          <main
            className={classNames(
              "min-h-[calc(100svh)] bg-gray-50",
              pathname !== "/app/db/" && pathname !== "/app/chat/"
                ? "pt-20"
                : "pt-16",
            )}
          >
            <div
              className={classNames(
                pathname !== "/app/db/" &&
                  pathname !== "/app/chat/" &&
                  "px-4 sm:px-6 lg:px-8",
              )}
            >
              {children}
            </div>
          </main>
        </div>
      </div>
    </>
  );
}
