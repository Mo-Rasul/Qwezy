import React from "react";

export default function HomeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div className="home-layout overflow-hidden">{children}</div>;
}
