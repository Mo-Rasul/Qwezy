const checkDangerousQuery = (queryText) => {
  const dangerousKeywords = ['DROP', 'DELETE', 'UPDATE', 'ALTER', 'TRUNCATE', 'INSERT', 'RENAME', 'CREATE', 'MODIFY'];

  const normalizedQuery = queryText.toUpperCase();

  // eslint-disable-next-line no-restricted-syntax
  for (const keyword of dangerousKeywords) {
    if (normalizedQuery.includes(keyword)) {
      throw new Error(`Execution of dangerous queries like "${keyword}" is not allowed.`);
    }
  }
};

module.exports = {
  checkDangerousQuery,
};
