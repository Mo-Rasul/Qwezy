-- DropForeignKey
ALTER TABLE `Query` DROP FOREIGN KEY `Query_databaseId_fkey`;

-- AddForeignKey
ALTER TABLE `Query` ADD CONSTRAINT `Query_databaseId_fkey` FOREIGN KEY (`databaseId`) REFERENCES `Database`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;
