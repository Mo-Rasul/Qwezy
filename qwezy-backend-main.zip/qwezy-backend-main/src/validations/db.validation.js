const Joi = require('joi');

const databaseValidationSchema = {
  body: Joi.object({
    host: Joi.string().required(),
    port: Joi.number().required(),
    username: Joi.string().required(),
    password: Joi.string().required(),
    databaseType: Joi.string().valid('MySQL', 'PostgreSQL', 'MSSQL').required(),
    databaseName: Joi.string().optional(),
  }),
};
const addDatabaseValidationSchema = {
  body: Joi.object({
    host: Joi.string().required(),
    port: Joi.number().required(),
    username: Joi.string().required(),
    password: Joi.string().required(),
    databaseType: Joi.string().valid('MySQL', 'PostgreSQL', 'MSSQL').required(),
    databaseName: Joi.string().optional(),
    name: Joi.string().required(),
  }),
};
const updateDatabaseValidationSchema = {
  params: Joi.object().keys({
    databaseId: Joi.string().required(),
  }),
  body: Joi.object({
    host: Joi.string().required(),
    port: Joi.number().required(),
    username: Joi.string().required(),
    password: Joi.string().required(),
    databaseType: Joi.string().valid('MySQL', 'PostgreSQL', 'MSSQL').required(),
    databaseName: Joi.string().optional(),
    name: Joi.string().required(),
  }),
};

const databaseIdValidationSchema = {
  params: Joi.object().keys({
    databaseId: Joi.string().required(),
  }),
};
const databaseTableValidationSchema = {
  params: Joi.object().keys({
    databaseId: Joi.string().required(),
    tableName: Joi.string().required(),
  }),
};
const executeQueryValidationScheme = {
  params: Joi.object().keys({
    databaseId: Joi.string().required(),
  }),
  body: {
    query: Joi.string().required(),
  },
};
const botQuery = {
  body: {
    query: Joi.string().required(),
  },
};

module.exports = {
  databaseValidationSchema,
  addDatabaseValidationSchema,
  updateDatabaseValidationSchema,
  databaseIdValidationSchema,
  databaseTableValidationSchema,
  executeQueryValidationScheme,
  botQuery,
};
