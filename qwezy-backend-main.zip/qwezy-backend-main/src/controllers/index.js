module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.dbController = require('./db.controller');
module.exports.statisticsController = require('./statistics.controller');
module.exports.chatController = require('./chat.controller');
