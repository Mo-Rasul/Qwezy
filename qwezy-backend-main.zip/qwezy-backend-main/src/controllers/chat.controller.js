const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { chatService } = require('../services');

const chatWithBot = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const { query } = req.body;

  const response = await chatService.sendMessageToBot(userId, query);
  res.status(httpStatus.OK).json(response);
});
const getMessages = catchAsync(async (req, res) => {
  const userId = req.user.id;

  const response = await chatService.getMessages(userId);
  res.status(httpStatus.OK).json(response);
});

module.exports = {
  chatWithBot,
  getMessages,
};
