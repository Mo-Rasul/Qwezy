const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { dbService } = require('../services');

const testConnection = catchAsync(async (req, res) => {
  const { host, port, username, password, databaseType, databaseName } = req.body;
  const dbName = databaseName || '';
  await dbService.testDatabaseConnection(databaseType, { host, port, username, password, databaseName: dbName });
  res.status(httpStatus.OK).json({ message: 'Connection successful!' });
});

const addDatabase = catchAsync(async (req, res) => {
  const { host, port, username, password, databaseType, databaseName, name } = req.body;
  const userId = req.user.id;

  const dbName = databaseName || '';
  await dbService.testDatabaseConnection(databaseType, { host, port, username, password, databaseName: dbName });

  await dbService.addDatabase(userId, { host, port, username, password, databaseType, databaseName, name });
  res.status(httpStatus.OK).json({ message: 'Database added successfully!' });
});

const getAllDatabases = catchAsync(async (req, res) => {
  const userId = req.user.id;

  const databases = await dbService.getAllDatabases(userId);
  res.status(httpStatus.OK).json(databases);
});

const deleteDatabase = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const { databaseId } = req.params;

  await dbService.deleteDatabase(databaseId, userId);
  res.status(httpStatus.OK).json({ message: 'Database deleted successfully' });
});

const updateDatabase = catchAsync(async (req, res) => {
  const { host, port, username, password, databaseType, databaseName, name } = req.body;
  const userId = req.user.id;
  const { databaseId } = req.params;

  const dbName = databaseName || '';
  await dbService.updateDatabase(databaseId, userId, {
    host,
    port,
    username,
    password,
    databaseType,
    databaseName: dbName,
    name,
  });
  res.status(httpStatus.OK).json({ message: 'Database updated successfully' });
});

const fetchTables = catchAsync(async (req, res) => {
  const { databaseId } = req.params;
  const userId = req.user.id;

  const tables = await dbService.fetchTablesFromRemoteDatabase(databaseId, userId);
  res.status(httpStatus.OK).json({ tables });
});
const fetchTableData = catchAsync(async (req, res) => {
  const { databaseId, tableName } = req.params;
  const userId = req.user.id;

  const data = await dbService.fetchTableData(databaseId, userId, tableName);
  res.status(httpStatus.OK).json({ data });
});
const executeQuery = catchAsync(async (req, res) => {
  const { databaseId } = req.params;
  const { query } = req.body;
  const userId = req.user.id;

  const { result, status, executionTime, errorMessage } = await dbService.executeQuery(databaseId, userId, query);
  res.status(httpStatus.OK).json({
    result,
    status,
    executionTime,
    errorMessage,
  });
});

module.exports = {
  testConnection,
  addDatabase,
  getAllDatabases,
  deleteDatabase,
  updateDatabase,
  fetchTables,
  fetchTableData,
  executeQuery,
};
