const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { statisticsService } = require('../services');

const getStatistics = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const statistics = await statisticsService.getStatisticsForUser(userId);

  res.status(httpStatus.OK).json(statistics);
});

module.exports = {
  getStatistics,
};
