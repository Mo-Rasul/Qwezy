const express = require('express');
const auth = require('../../middlewares/auth');
const { statisticsController } = require('../../controllers');

const router = express.Router();

router.route('/').get(auth('getUsers'), statisticsController.getStatistics);

module.exports = router;
