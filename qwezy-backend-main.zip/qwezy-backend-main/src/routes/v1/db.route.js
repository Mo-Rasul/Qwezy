const express = require('express');
const { dbController } = require('../../controllers');
const validate = require('../../middlewares/validate');
const dbValidation = require('../../validations/db.validation');
const auth = require('../../middlewares/auth');

const router = express.Router();

router.route('/').get(auth('updateInformation'), dbController.getAllDatabases);

router
  .route('/test-connection')
  .post(auth('updateInformation'), validate(dbValidation.databaseValidationSchema), dbController.testConnection);

router
  .route('/add-database')
  .post(auth('updateInformation'), validate(dbValidation.addDatabaseValidationSchema), dbController.addDatabase);

router
  .route('/:databaseId')
  .delete(auth('updateInformation'), validate(dbValidation.databaseIdValidationSchema), dbController.deleteDatabase);

router
  .route('/:databaseId')
  .put(auth('updateInformation'), validate(dbValidation.updateDatabaseValidationSchema), dbController.updateDatabase);

router
  .route('/tables/:databaseId')
  .get(auth('updateInformation'), validate(dbValidation.databaseIdValidationSchema), dbController.fetchTables);

router
  .route('/tables/:databaseId/:tableName')
  .get(auth('updateInformation'), validate(dbValidation.databaseTableValidationSchema), dbController.fetchTableData);

router
  .route('/execute-query/:databaseId')
  .post(auth('updateInformation'), validate(dbValidation.executeQueryValidationScheme), dbController.executeQuery);

module.exports = router;

/**
 * @swagger
 * /databases:
 *   get:
 *     summary: Get all databases for the authenticated user
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of databases
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: string
 *                     example: "16charstring1"
 *                   name:
 *                     type: string
 *                     example: "My Database"
 *                   type:
 *                     type: string
 *                     example: "MySQL"
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /databases/test-connection:
 *   post:
 *     summary: Test connection to the provided database
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               host:
 *                 type: string
 *                 example: "localhost"
 *               port:
 *                 type: integer
 *                 example: 3306
 *               username:
 *                 type: string
 *                 example: "root"
 *               password:
 *                 type: string
 *                 example: "password"
 *               databaseType:
 *                 type: string
 *                 example: "MySQL"
 *               databaseName:
 *                 type: string
 *                 example: "test_db"
 *     responses:
 *       200:
 *         description: Connection successful
 *       400:
 *         description: Bad request
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /databases/add-database:
 *   post:
 *     summary: Add a new database
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: "My Database"
 *               host:
 *                 type: string
 *                 example: "localhost"
 *               port:
 *                 type: integer
 *                 example: 3306
 *               username:
 *                 type: string
 *                 example: "root"
 *               password:
 *                 type: string
 *                 example: "password"
 *               databaseType:
 *                 type: string
 *                 example: "MySQL"
 *               databaseName:
 *                 type: string
 *                 example: "test_db"
 *     responses:
 *       201:
 *         description: Database added
 *       400:
 *         description: Bad request
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /databases/{databaseId}:
 *   delete:
 *     summary: Delete a database by ID
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: databaseId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Database deleted
 *       404:
 *         description: Database not found
 *       500:
 *         description: Server error
 *
 *   put:
 *     summary: Update a database by ID
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: databaseId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: "Updated Database"
 *               host:
 *                 type: string
 *                 example: "localhost"
 *               port:
 *                 type: integer
 *                 example: 3306
 *               username:
 *                 type: string
 *                 example: "root"
 *               password:
 *                 type: string
 *                 example: "password"
 *               databaseType:
 *                 type: string
 *                 example: "MySQL"
 *               databaseName:
 *                 type: string
 *                 example: "test_db"
 *     responses:
 *       200:
 *         description: Database updated
 *       404:
 *         description: Database not found
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /databases/tables/{databaseId}:
 *   get:
 *     summary: Get all tables from a database
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: databaseId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: A list of tables
 *       404:
 *         description: Database not found
 */

/**
 * @swagger
 * /databases/tables/{databaseId}/{tableName}:
 *   get:
 *     summary: Get data from a table in the database
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: databaseId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: tableName
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Data from the table
 *       404:
 *         description: Table not found
 */

/**
 * @swagger
 * /databases/execute-query/{databaseId}:
 *   post:
 *     summary: Execute a query on a database
 *     tags: [Database Management]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: databaseId
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               queryText:
 *                 type: string
 *                 example: "SELECT * FROM users"
 *     responses:
 *       200:
 *         description: Query executed
 *       400:
 *         description: Invalid query or dangerous query
 *       500:
 *         description: Server error
 */
