const express = require('express');
const { chatController } = require('../../controllers');
const validate = require('../../middlewares/validate');
const dbValidation = require('../../validations/db.validation');
const auth = require('../../middlewares/auth');

const router = express.Router();

router.route('/').post(auth('updateInformation'), validate(dbValidation.botQuery), chatController.chatWithBot);
router.route('/').get(auth('updateInformation'), chatController.getMessages);

module.exports = router;
