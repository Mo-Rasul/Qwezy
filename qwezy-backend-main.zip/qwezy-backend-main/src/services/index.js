module.exports.authService = require('./auth.service');
module.exports.emailService = require('./email.service');
module.exports.tokenService = require('./token.service');
module.exports.userService = require('./user.service');
module.exports.dbService = require('./db.service');
module.exports.statisticsService = require('./statistics.service');
module.exports.chatService = require('./chat.service');
