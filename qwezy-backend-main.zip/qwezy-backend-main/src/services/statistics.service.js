const { startOfMonth, endOfMonth, eachDayOfInterval, format } = require('date-fns');
const { prisma } = require('../prisma/prisma-connection');

const getStatisticsForUser = async (userId) => {
  const now = new Date();
  const startDate = startOfMonth(now);
  const endDate = endOfMonth(now);

  // Get all days of the current month
  const daysInMonth = eachDayOfInterval({
    start: startDate,
    end: endDate,
  }).map((date) => format(date, 'd'));

  // Resources hit per day for Token, Database, and Query
  const tokenHits = await prisma.token.groupBy({
    by: ['createdAt'],
    _count: true,
    where: {
      userId,
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  });

  const databaseHits = await prisma.database.groupBy({
    by: ['createdAt'],
    _count: true,
    where: {
      userId,
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  });

  const queryHits = await prisma.query.groupBy({
    by: ['createdAt'],
    _count: true,
    where: {
      database: {
        userId,
      },
      createdAt: {
        gte: startDate,
        lte: endDate,
      },
    },
  });

  //   console.log(tokenHits, databaseHits, queryHits);

  // Combine hits for all resources
  const hitsByDay = daysInMonth.map((day) => {
    const filterHitsForDay = (hits) => hits.filter((hit) => new Date(hit.createdAt).getDate().toString() === day);

    const tokenHitsForDay = filterHitsForDay(tokenHits);
    const databaseHitsForDay = filterHitsForDay(databaseHits);
    const queryHitsForDay = filterHitsForDay(queryHits);

    const totalCount =
      tokenHitsForDay.reduce((sum, hit) => sum + hit._count, 0) +
      databaseHitsForDay.reduce((sum, hit) => sum + hit._count, 0) +
      queryHitsForDay.reduce((sum, hit) => sum + hit._count, 0);

    return totalCount;
  });

  // Get distinct database types and their counts
  const databaseTypeCounts = await prisma.database.groupBy({
    by: ['type'],
    _count: {
      type: true,
    },
    where: {
      userId,
    },
  });

  const databasesTypes = [
    {
      name: 'MS SQL',
      value: databaseTypeCounts.find((db) => db.type === 'MS SQL')
        ? databaseTypeCounts.find((db) => db.type === 'MS SQL')._count.type
        : 0,
    },
    {
      name: 'MySQL',
      value: databaseTypeCounts.find((db) => db.type === 'MySQL')
        ? databaseTypeCounts.find((db) => db.type === 'MySQL')._count.type
        : 0,
    },
    {
      name: 'PostGreSQL',
      value: databaseTypeCounts.find((db) => db.type === 'PostGreSQL')
        ? databaseTypeCounts.find((db) => db.type === 'PostGreSQL')._count.type
        : 0,
    },
  ];

  // Get success and failure rate for queries
  const queryStatusCounts = await prisma.query.groupBy({
    by: ['status'],
    _count: {
      status: true,
    },
    where: {
      database: {
        userId,
      },
    },
  });

  // Find the entries for failed and successful queries
  const failEntry = queryStatusCounts.find((q) => q.status === 'failed');
  const successEntry = queryStatusCounts.find((q) => q.status === 'success');

  // Get the count of failed and successful queries, default to 0 if not found
  const failCount = failEntry ? failEntry._count.status : 0;
  const successCount = successEntry ? successEntry._count.status : 0;

  // Calculate the total number of queries
  const totalQueries = failCount + successCount;

  // Calculate the percentage for failed and successful queries and round to 2 decimal places
  const failPercentage = totalQueries > 0 ? ((failCount / totalQueries) * 100).toFixed(2) : '0.00';
  const successPercentage = totalQueries > 0 ? ((successCount / totalQueries) * 100).toFixed(2) : '0.00';

  // Prepare the success-fail rate data
  const successFailRate = [
    { name: 'fail', value: parseFloat(failPercentage) },
    { name: 'success', value: parseFloat(successPercentage) },
  ];

  return {
    resources_hit_per_month: {
      months: daysInMonth,
      hit_value: hitsByDay,
    },
    databases_types: databasesTypes,
    success_fail_rate: successFailRate,
  };
};

module.exports = {
  getStatisticsForUser,
};
