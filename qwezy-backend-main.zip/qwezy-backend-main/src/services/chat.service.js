const OpenAI = require('openai');
const { prisma } = require('../prisma/prisma-connection');

const client = new OpenAI({
  apiKey:
    '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',
});

const ASSISTANT_ID = 'asst_OrgUuxQRGaJfeWYs1BbTTp3H';

// Helper function to wait for the assistant to finish processing
const waitForAssistant = async (threadId, runId) => {
  let isCompleted = false;

  while (!isCompleted) {
    // Check the status of the run
    // eslint-disable-next-line no-await-in-loop
    const runStatus = await client.beta.threads.runs.retrieve(threadId, runId);

    if (runStatus.status === 'completed') {
      isCompleted = true;
    } else {
      // Wait for a short period before checking again (e.g., 1 second)
      // eslint-disable-next-line no-await-in-loop
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }
};

function parseConversation(data) {
  const messages = data.body.data;

  const conversation = messages
    .map((message) => {
      if (message.role === 'assistant' || message.role === 'user') {
        return {
          role: message.role,
          content: message.content[0].text.value || '',
          createdAt: message.created_at,
        };
      }
      return null;
    })
    .filter(Boolean); // Filter out any null values

  return conversation;
}

const sendMessageToBot = async (userId, query) => {
  if (!userId) {
    throw new Error(`Only authenticated users are allowed to access this`);
  }

  const chatToWork = await prisma.chat.findFirst({
    where: {
      userId: parseInt(userId, 10),
    },
  });

  let response;

  if (!chatToWork) {
    const thread = await client.beta.threads.create();

    // Save the thread in the database
    await prisma.chat.create({
      data: {
        userId,
        threadId: thread.id,
      },
    });

    // Send user message
    await client.beta.threads.messages.create(thread.id, {
      role: 'user',
      content: query,
    });

    // Run the assistant
    const runResponse = await client.beta.threads.runs.create(thread.id, {
      assistant_id: ASSISTANT_ID,
    });

    // Wait for the assistant to complete the response
    await waitForAssistant(thread.id, runResponse.id);

    // Get the messages including the assistant's response
    const messages = await client.beta.threads.messages.list(thread.id);
    response = messages;
  } else {
    // If the thread already exists, just continue in the existing thread
    await client.beta.threads.messages.create(chatToWork.threadId, {
      role: 'user',
      content: query,
    });

    // Run the assistant
    const runResponse = await client.beta.threads.runs.create(chatToWork.threadId, {
      assistant_id: ASSISTANT_ID,
    });

    // Wait for the assistant to complete the response
    await waitForAssistant(chatToWork.threadId, runResponse.id);

    // Get the messages including the assistant's response
    const messages = await client.beta.threads.messages.list(chatToWork.threadId);
    response = messages;
  }

  return parseConversation(response);
};

const getMessages = async (userId) => {
  if (!userId) {
    throw new Error(`Only authenticated users are allowed to access this`);
  }

  const chatToWork = await prisma.chat.findFirst({
    where: {
      userId: parseInt(userId, 10),
    },
  });

  let response;

  if (!chatToWork) {
    response = [];
  } else {
    const messages = await client.beta.threads.messages.list(chatToWork.threadId);
    response = messages;
  }

  return parseConversation(response);
};

module.exports = {
  sendMessageToBot,
  getMessages,
};
