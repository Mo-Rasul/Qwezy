const mysql = require('mysql2/promise');
const { Client: PgClient } = require('pg');
const { ConnectionPool } = require('mssql');
const { prisma } = require('../prisma/prisma-connection');
const { checkDangerousQuery } = require('../middlewares/sqlQueryValidator');

const buildConnectionString = (databaseType, { host, port, username, password, databaseName }) => {
  switch (databaseType) {
    case 'MySQL':
      return `mysql://${username}:${password}@${host}:${port}/${databaseName}`;
    case 'PostgreSQL':
      return `postgresql://${username}:${password}@${host}:${port}/${databaseName}`;
    case 'MSSQL':
      return JSON.stringify({
        user: username,
        password,
        server: host,
        port,
        database: databaseName,
        options: { encrypt: true, trustServerCertificate: true },
      });
    default:
      throw new Error('Unsupported database type');
  }
};

const testDatabaseConnection = async (databaseType, connectionDetails) => {
  try {
    switch (databaseType) {
      case 'MySQL': {
        const connection = await mysql.createConnection(buildConnectionString(databaseType, connectionDetails));
        await connection.query('SELECT 1');
        connection.end();
        break;
      }
      case 'PostgreSQL': {
        const client = new PgClient({
          connectionString: buildConnectionString(databaseType, connectionDetails),
        });
        await client.connect();
        await client.query('SELECT 1');
        await client.end();
        break;
      }
      case 'MSSQL': {
        const pool = new ConnectionPool(JSON.parse(buildConnectionString(databaseType, connectionDetails)));
        await pool.connect();
        await pool.query('SELECT 1');
        pool.close();
        break;
      }
      default:
        throw new Error('Unsupported database type');
    }
  } catch (error) {
    throw new Error(`Failed to connect to the ${databaseType} database: ${error.message}`);
  }
};

const addDatabase = async (userId, connectionDetails) => {
  try {
    await prisma.database.create({
      data: {
        userId,
        connectionString: buildConnectionString(connectionDetails.databaseType, connectionDetails),
        type: connectionDetails.databaseType,
        name: connectionDetails.name,
      },
    });
  } catch (error) {
    throw new Error(`Failed to add database: ${error.message}`);
  }
};

const getAllDatabases = async (userId) => {
  try {
    const databases = await prisma.database.findMany({
      where: {
        userId,
      },
    });

    // Remove the connectionString field from each database object
    const sanitizedDatabases = databases.map(({ connectionString, ...rest }) => rest);

    return sanitizedDatabases;
  } catch (error) {
    throw new Error(`Failed to fetch databases: ${error.message}`);
  }
};

const deleteDatabase = async (databaseId, userId) => {
  try {
    const dbToDelete = await prisma.database.findFirst({
      where: {
        id: parseInt(databaseId, 10),
        userId: parseInt(userId, 10),
      },
    });

    if (!dbToDelete) {
      throw new Error('Database not found or you don’t have permission to delete it.');
    }

    await prisma.database.delete({
      where: {
        id: parseInt(databaseId, 10),
      },
    });
  } catch (error) {
    throw new Error(`Failed to delete database: ${error.message}`);
  }
};

const updateDatabase = async (databaseId, userId, updateDetails) => {
  try {
    const dbToUpdate = await prisma.database.findFirst({
      where: {
        id: parseInt(databaseId, 10),
        userId: parseInt(userId, 10),
      },
    });

    if (!dbToUpdate) {
      throw new Error('Database not found or you don’t have permission to update it.');
    }

    await testDatabaseConnection(updateDetails.databaseType, updateDetails);

    return await prisma.database.update({
      where: {
        id: parseInt(databaseId, 10),
      },
      data: {
        connectionString: buildConnectionString(updateDetails.databaseType, updateDetails),
        type: updateDetails.databaseType,
        name: updateDetails.databaseName,
      },
    });
  } catch (error) {
    throw new Error(`Failed to update database: ${error.message}`);
  }
};

const fetchTablesFromRemoteDatabase = async (databaseId, userId) => {
  try {
    // Fetch database details from our Database table using Prisma
    const databaseDetails = await prisma.database.findFirst({
      where: {
        id: parseInt(databaseId, 10),
        userId: parseInt(userId, 10),
      },
    });

    if (!databaseDetails) {
      throw new Error('Database not found or you don’t have permission to access it.');
    }

    const { type, connectionString } = databaseDetails;
    let tables = [];

    // Connect and fetch tables based on the database type
    switch (type) {
      case 'MySQL': {
        const connection = await mysql.createConnection(connectionString);
        const [rows] = await connection.query('SHOW TABLES');
        tables = rows.map((row) => {
          const tableNameKey = Object.keys(row)[0];
          return { tableName: row[tableNameKey] };
        });
        connection.end();
        break;
      }
      case 'PostgreSQL': {
        const client = new PgClient({ connectionString });
        await client.connect();
        const result = await client.query(`
              SELECT table_name 
              FROM information_schema.tables 
              WHERE table_schema='public'
            `);
        tables = result.rows.map((row) => ({ tableName: row.table_name }));
        await client.end();
        break;
      }
      case 'MSSQL': {
        const pool = new ConnectionPool(connectionString);
        await pool.connect();
        const result = await pool.query(`
              SELECT TABLE_NAME 
              FROM INFORMATION_SCHEMA.TABLES 
              WHERE TABLE_TYPE='BASE TABLE'
            `);
        tables = result.recordset.map((row) => ({ tableName: row.TABLE_NAME }));
        pool.close();
        break;
      }
      default:
        throw new Error('Unsupported database type');
    }

    return tables;
  } catch (error) {
    throw new Error(`Failed to fetch tables: ${error.message}`);
  }
};
const fetchTableData = async (databaseId, userId, tableName) => {
  try {
    // Fetch database details from our Database table using Prisma
    const databaseDetails = await prisma.database.findFirst({
      where: {
        id: parseInt(databaseId, 10),
        userId: parseInt(userId, 10),
      },
    });

    if (!databaseDetails) {
      throw new Error('Database not found or you don’t have permission to access it.');
    }

    const { type, connectionString } = databaseDetails;
    let data = [];
    let columns = [];

    // Connect and fetch data from the specified table, limited to 1000 records
    switch (type) {
      case 'MySQL': {
        const connection = await mysql.createConnection(connectionString);
        try {
          const [rows] = await connection.query(`SELECT * FROM \`${tableName}\` LIMIT 1000`);
          data = rows.map((row) => ({ ...row }));

          // Fetch column names from information_schema
          const [cols] = await connection.query(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ?`, [
            tableName,
          ]);
          columns = cols.map((col) => col.COLUMN_NAME);
        } catch (err) {
          if (err.code === 'ER_NO_SUCH_TABLE') {
            throw new Error(`Table "${tableName}" not found in the database.`);
          } else {
            throw new Error(`Error executing query: ${err.message}`);
          }
        } finally {
          connection.end();
        }
        break;
      }
      case 'PostgreSQL': {
        const client = new PgClient({ connectionString });
        try {
          await client.connect();
          const result = await client.query(`SELECT * FROM "${tableName}" LIMIT 1000`);
          data = result.rows.map((row) => ({ ...row }));

          // Fetch column names
          const columnResult = await client.query(
            `SELECT column_name FROM information_schema.columns WHERE table_name = $1`,
            [tableName]
          );
          columns = columnResult.rows.map((col) => col.column_name);
        } catch (err) {
          if (err.code === '42P01') {
            throw new Error(`Table "${tableName}" not found in the database.`);
          } else {
            throw new Error(`Error executing query: ${err.message}`);
          }
        } finally {
          await client.end();
        }
        break;
      }
      case 'MSSQL': {
        const pool = new ConnectionPool(connectionString);
        try {
          await pool.connect();
          const result = await pool.query(`SELECT TOP 1000 * FROM [${tableName}]`);
          data = result.recordset.map((row) => ({ ...row }));

          // Fetch column names
          const columnResult = await pool.query(
            `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '${tableName}'`
          );
          columns = columnResult.recordset.map((col) => col.COLUMN_NAME);
        } catch (err) {
          if (err.originalError && err.originalError.info && err.originalError.info.number === 208) {
            throw new Error(`Table "${tableName}" not found in the database.`);
          } else {
            throw new Error(`Error executing query: ${err.message}`);
          }
        } finally {
          pool.close();
        }
        break;
      }
      default:
        throw new Error('Unsupported database type');
    }

    return { tableName, columns, records: data };
  } catch (error) {
    throw new Error(`Failed to fetch data from table "${tableName}": ${error.message}`);
  }
};

const executeQuery = async (databaseId, userId, queryText) => {
  const startTime = Date.now();
  let status = 'in-progress';
  let executionTime = null;
  let errorMessage = null;
  let result = null;

  try {
    // Check if the query is dangerous
    checkDangerousQuery(queryText);

    // Fetch database details from our Database table using Prisma
    const databaseDetails = await prisma.database.findFirst({
      where: {
        id: parseInt(databaseId, 10),
        userId: parseInt(userId, 10),
      },
    });

    if (!databaseDetails) {
      throw new Error('Database not found or you don’t have permission to access it.');
    }

    const { type, connectionString } = databaseDetails;

    // Connect and execute query based on the database type
    switch (type) {
      case 'MySQL': {
        const connection = await mysql.createConnection(connectionString);
        try {
          [result] = await connection.query(queryText);
          status = 'success';
        } catch (err) {
          status = 'failed';
          errorMessage = err.message;
        } finally {
          connection.end();
        }
        break;
      }
      case 'PostgreSQL': {
        const client = new PgClient({ connectionString });
        try {
          await client.connect();
          const queryResult = await client.query(queryText);
          result = queryResult.rows;
          status = 'success';
        } catch (err) {
          status = 'failed';
          errorMessage = err.message;
        } finally {
          await client.end();
        }
        break;
      }
      case 'MSSQL': {
        const pool = new ConnectionPool(connectionString);
        try {
          await pool.connect();
          const queryResult = await pool.query(queryText);
          result = queryResult.recordset;
          status = 'success';
        } catch (err) {
          status = 'failed';
          errorMessage = err.message;
        } finally {
          pool.close();
        }
        break;
      }
      default:
        throw new Error('Unsupported database type');
    }

    // Calculate execution time
    executionTime = (Date.now() - startTime) / 1000;

    // Store query details in the system
    await prisma.query.create({
      data: {
        query: queryText,
        status,
        errorMessage,
        executionTime,
        databaseId: parseInt(databaseId, 10),
      },
    });

    return { result, status, executionTime, errorMessage };
  } catch (error) {
    throw new Error(`Failed to execute query: ${error.message}`);
  }
};

module.exports = {
  testDatabaseConnection,
  addDatabase,
  getAllDatabases,
  deleteDatabase,
  updateDatabase,
  fetchTablesFromRemoteDatabase,
  fetchTableData,
  executeQuery,
};
